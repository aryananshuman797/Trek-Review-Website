# Trekking-Sites

◦ Designed aNode.js-based website and implemented RESTful and CRUD functionalities with the help of Express.js,
  MongoDB database technology. Authentication feature was implemented using Passport.js.
◦ Users can share, rate and explore and also sort the sites based on different parameters.
